s = rng;
rng(2020);
scene = trackingScenario('IsEarthCentered',true, 'InitialAdvance', 'UpdateInterval',...
    'StopTime', 3600, 'UpdateRate', 0.1);

% Generate a population of debris
numDebris = 10;

range = linspace(7e6,2e7,numDebris); %range within space
ecc = 0.015 + 0.005*randn(numDebris,1); %eccentricity
inc = 80 + 10*rand(numDebris,1); %inclination
lan = 360*rand(numDebris,1); %longitude of ascending node?
w = 360*rand(numDebris,1); % argument of periapsis
nu = 360*rand(numDebris,1); % true anamoly

% Convert to initial position and velocity
for i = 1:numDebris
    %converts initial state to geocentric frame
    [r,v] = oe2rv(range(i),ecc(i),inc(i),lan(i),w(i),nu(i));
    data(i).InitialPosition = r; %#ok<SAGROW>
    data(i).InitialVelocity = v; %#ok<SAGROW>
end

% Create platforms and assign them trajectories using the keplerorbit motion model
for i=1:numDebris
    debris(i) = platform(scene); %#ok<SAGROW> 
    debris(i).Trajectory = helperMotionTrajectory(@keplerorbit,...
        'SampleRate',0.1,... % integration step 10sec
        'Position',data(i).InitialPosition,...
        'Velocity',data(i).InitialVelocity); %#ok<SAGROW> 
     
end

plot3(debris(1).Trajectory.Position(1),debris(1).Trajectory.Position(2),debris(1).Trajectory.Position(3))
% Create a space surveillance station in the Pacific ocean
station1 = platform(scene,'Position',[10 180 0]);

% Create a second surveillance station in the Atlantic ocean
station2 = platform(scene,'Position',[0 -20 0]);

% Near the North Pole, create a third surveillance station in Iceland
station3 = platform(scene,'Position',[65 -20 0]);

% Create a fourth surveillance station near the south pole
station4 = platform(scene,'Position',[-90 0 0]);


% Create fan-shaped monostatic radars to monitor space debris objects
radar1 = fusionRadarSensor(1,...
    'UpdateRate',0.1,... 10 sec
    'ScanMode','No scanning',...
    'MountingAngles',[0 90 0],... look up
    'FieldOfView',[120;30],... degrees
    'ReferenceRange',2e6,... m
    'RangeLimits', [0 2e6],...
    'ReferenceRCS', 10,... dBsm
    'HasFalseAlarms',false,...
    'HasElevation',true,...
    'AzimuthResolution',0.01,... degrees
    'ElevationResolution',0.01,... degrees
    'RangeResolution',100,... m
    'HasINS',true,...
    'DetectionCoordinates','Scenario');
station1.Sensors = radar1;

radar2 = clone(radar1);
radar2.SensorIndex = 2;
station2.Sensors = radar2;

radar3 = clone(radar1);
radar3.SensorIndex = 3;
station3.Sensors = radar3;

radar4 = clone(radar1);
radar4.SensorIndex = 4;
station4.Sensors = radar4;

globeDisplay = helperScenarioGlobeViewer;

% Show radar beams on the globe
covcon = coverageConfig(scene);
plotCoverage(globeDisplay,covcon);

% Set TargetHistoryLength to visualize the full trajectory of the debris objects
globeDisplay.TargetHistoryLength = 100;

scene.StopTime = 3600;
scene.UpdateRate = 0.1;

while advance(scene)
    time = scene.SimulationTime;
    updateDisplay(globeDisplay,time,debris);
end
snap(globeDisplay);


% Define Tracker
tracker = trackerJPDA('FilterInitializationFcn',@initKeplerUKF,...
    'HasDetectableTrackIDsInput',true,...
    'ClutterDensity',1e-20,...
    'AssignmentThreshold',1e3,...
    'DeletionThreshold',[7 10]);

% Reset scenario, seed, and globe display
restart(scene);
scene.StopTime = 1800; % 30 min
clear(globeDisplay);
globeDisplay.TargetHistoryLength = 2;
% Scale up size of covariance ellipses for better visibility
globeDisplay.DetectionCovarianceSize = 10;
globeDisplay.TrackCovarianceSize = 10;
plotCoverage(globeDisplay,covcon);

% Initialize tracks
confTracks = objectTrack.empty(0,1);
while advance(scene)
    time = scene.SimulationTime;
    
    % Generate detections
    detections = detect(scene);
    
    % Generate and update tracks
    detectableInput = isDetectable(tracker,time, covcon);
    if ~isempty(detections) || isLocked(tracker)
        [confTracks, ~, allTracks,info] = tracker(detections,time,detectableInput);
        confTracks = deleteBadTracks(tracker,confTracks);
    end

    % Update globe display
    updateDisplay(globeDisplay,time,debris,detections,[],confTracks);
    
        
end

% Restore random seed
rng(s);

