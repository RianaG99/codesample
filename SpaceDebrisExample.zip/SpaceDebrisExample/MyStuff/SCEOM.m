function stateChange = SCEOM(t,state, mu)


r = state(1:3);
v = state(4:6);

mag_r = norm(r);

r_dot = v;

v_dot = (-mu/(mag_r)^3)*r;



stateChange = [r_dot; v_dot];
end