numDebris = 5; % number of tracked objects 
%numDebris = 254729; ALL OBJECTS IN THIS RANGE
vmin = 7; % max and min values for the magnitudes of the debris
vmax = 8;
mu = 398600;
R_earth = 6378; %kmcl

rmin = R_earth + 799; %km , CHANGED RANGE TO 1 KM OF SPACE 
rmax = R_earth + 800; %km

tspan = 0:60:32000; %time for ODE, ONE SECOND
%tspan = 0:.143:32000; FOR 1 KM A SECOND
%tspan = 0:.07:32000; FOR .5 KM A SECOND
%tspan = 0:.07:16000; SIMULATE ABOVE FOR 6 MONTHS INSTEAD IF OTHER IS BIG




%pre allocate empty arrays for r and v initial conditions
r = [0 0 0]';
v = [0 0 0]';

k = 1;

for i = 1:numDebris
    
    
    
    if k == 1
        
        r(1,i) =  rmin+rand(1,1)*(rmax-rmin);
        r(2,i) = rmax*(2*rand(1,1)-1);
        r(3,i) = rmax*(2*rand(1,1)-1);
        
        
    end
    
    if k == 2
        
        r(2,i) =  rmin+rand(1,1)*(rmax-rmin);
        r(1,i) = rmax*(2*rand(1,1)-1);
        r(3,i) = rmax*(2*rand(1,1)-1);
        
    end
    if k == 3
        
        r(3,i) =  rmin+rand(1,1)*(rmax-rmin);
        r(1,i) = rmax*(2*rand(1,1)-1);
        r(2,i) = rmax*(2*rand(1,1)-1);
    end
        if k == 4
        
        r(1,i) =  -rmin-rand(1,1)*(rmax-rmin);
        r(2,i) = rmax*(2*rand(1,1)-1);
        r(3,i) = rmax*(2*rand(1,1)-1);
        
        
    end
    
    if k == 5
        
        r(2,i) =  -rmin-rand(1,1)*(rmax-rmin);
        r(1,i) = rmax*(2*rand(1,1)-1);
        r(3,i) = rmax*(2*rand(1,1)-1);
        
    end
    if k == 6
        
        r(3,i) =  -rmin-rand(1,1)*(rmax-rmin);
        r(1,i) = rmax*(2*rand(1,1)-1);
        r(2,i) = rmax*(2*rand(1,1)-1);
    end
     
     
 

  

  
  %Randomize values of velocity with magnitude smaller than 8
  for j = 1:length(3)
  v(j,i) = vmax*rand(1,1);
  if norm(v(:,i)) > 8
  
   v(j,i) = 0;
      
  end
  end
  
  while norm(v(:,i)) < 7
      
  v(:,i) = v(:,i) + [.5; .5; .5];
      
  end
  
  k = k+1;
  
  if k == 7
      
      k = 1;
      
  end
          
end

%set low relative tolerance
options = odeset('RelTol',1e-12,'AbsTol',1e-12);

 for i = 1:numDebris
     
initial_state = [ r(:,i); v(:,i)];
%run the ode for respective 
[t,X] = ode45(@(t,state) SCEOM(t,state, mu),tspan, initial_state, options);

%store each debris data into its own struct
debris(i).Trajectory = X(:,1:3);

 end

 %collision conditions
hit = [1 1 1];
%count amount of conditions
collide = 0;


 for i = 1:numDebris
     
     for j = 1:numDebris
           if i == j
               bool = [0 0 0];
           else
             %range where there is a collision 
             bool = (debris(j).Trajectory - .15 <= debris(i).Trajectory) & (debris(i).Trajectory <= .15 + debris(j).Trajectory);
            for k = 1:length(bool)
                if bool(k,:) == hit 
                    %collide if x,y,z point all 1
                    collide = collide + 1;
                    %break once first collision is found since it could keep
                    %colliding
                    break 
                end
            end
         end        
    end
 end
    
