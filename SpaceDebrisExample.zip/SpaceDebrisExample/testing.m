numDebris = 2
range = linspace(7e6,2e7,numDebris); %range within space
ecc = 0.015 + 0.005*randn(numDebris,1); %eccentricity
inc = 80 + 10*rand(numDebris,1); %inclination
lan = 360*rand(numDebris,1); %longitude of ascending node?
w = 360*rand(numDebris,1); % argument of periapsis
nu = 360*rand(numDebris,1); % true anamoly

% Convert to initial position and velocity
for i = 1:numDebris
    %converts initial state to geocentric frame
    [r,v] = oe2rv(range(i),ecc(i),inc(i),lan(i),w(i),nu(i));
    data(i).InitialPosition = r; %#ok<SAGROW>
    data(i).InitialVelocity = v; %#ok<SAGROW>
end